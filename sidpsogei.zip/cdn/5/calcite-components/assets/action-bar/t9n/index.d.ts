export type ActionBarMessages = {
  expand: string;
  collapse: string;
};
